function getBotResponse(message) {
  const msg = message.toLowerCase();

  if (msg.includes("hallo") || msg.includes("hi")) {
    return "Hallo! Schön, dich zu sehen. Wie kann ich dir helfen?";
  } else if (msg.includes("wie geht") || msg.includes("wie läuft's")) {
    return "Mir geht's gut, danke! Und dir?";
  } else if (msg.includes("hilfe") || msg.includes("problem")) {
    return "Erzähl mir mehr über dein Problem – ich helfe dir gern weiter.";
  } else if (msg.includes("danke")) {
    return "Gern geschehen! 😊";
  } else if (msg.endsWith("?")) {
    return "Das ist eine interessante Frage. Ich denke darüber nach...";
  } else {
    return "Erzähl mir mehr – ich bin ganz Ohr!";
  }
}

module.exports = { getBotResponse };